package com.realsnow.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;

/**
 * Client-only extras. The rounded snow shapes + soft texture come from the mod's resource assets
 * (assets/minecraft/blockstates/snow.json + assets/realsnow/models), so no rendering internals are touched.
 * This class adds denser, softer snowfall.
 */
public class RealSnowClient implements ClientModInitializer {
	private static final int FLAKES_PER_TICK = 6;
	private static final double SPREAD = 28.0;

	@Override
	public void onInitializeClient() {
		// END_CLIENT_TICK is not one of the renamed *_WORLD_TICK events.
		ClientTickEvents.END_CLIENT_TICK.register(RealSnowClient::onTick);
	}

	private static void onTick(Minecraft mc) {
		var level = mc.level;
		var player = mc.player;
		if (level == null || player == null || mc.isPaused() || !level.isRaining()) return;

		var random = level.getRandom();
		for (int i = 0; i < FLAKES_PER_TICK; i++) {
			double x = player.getX() + (random.nextDouble() - 0.5) * 2.0 * SPREAD;
			double z = player.getZ() + (random.nextDouble() - 0.5) * 2.0 * SPREAD;
			double y = player.getY() + 2.0 + random.nextDouble() * 10.0;

			BlockPos pos = BlockPos.containing(x, y, z);
			if (!level.canSeeSky(pos)) continue;
			if (!level.getBiome(pos).value().coldEnoughToSnow(pos, level.getSeaLevel())) continue;

			double drift = (random.nextDouble() - 0.5) * 0.02;
			level.addParticle(ParticleTypes.SNOWFLAKE, x, y, z, drift, -0.04, drift);
		}
	}
}
