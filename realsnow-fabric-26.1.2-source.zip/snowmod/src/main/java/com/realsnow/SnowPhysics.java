package com.realsnow;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SnowLayerBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;

public final class SnowPhysics {
	/** Max snow layers that can pile up from snowfall (8 layers = full block). 5 stays walkable without jumping. */
	private static final int MAX_LAYERS = 5;
	/** Horizontal radius around each player where snow builds up. */
	private static final int RADIUS = 32;
	/** Random columns tried per player per tick. Higher = faster buildup. */
	private static final int ATTEMPTS_PER_TICK = 10;
	/** Radius around each player in which walking creatures leave footprints. */
	private static final double TRAIL_RANGE = 24.0;

	private static final Map<UUID, Long> LAST_BLOCK = new HashMap<>();
	private static long tickCounter = 0;

	private SnowPhysics() {}

	public static void onServerTick(MinecraftServer server) {
		tickCounter++;
		for (ServerLevel level : server.getAllLevels()) {
			if (level.players().isEmpty()) continue;
			trampleSnow(level);
			if (level.isRaining()) accumulate(level);
		}
		// Cheap leak guard: forget tracked positions now and then (worst case: one skipped/extra footprint).
		if (tickCounter % 6000 == 0) LAST_BLOCK.clear();
	}

	/** Creatures (and players) that step onto a new block compress the snow layers there by one. */
	private static void trampleSnow(ServerLevel level) {
		for (ServerPlayer player : level.players()) {
			AABB box = new AABB(
				player.getX() - TRAIL_RANGE, player.getY() - 8, player.getZ() - TRAIL_RANGE,
				player.getX() + TRAIL_RANGE, player.getY() + 8, player.getZ() + TRAIL_RANGE);
			for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, box)) {
				if (!entity.onGround()) continue;
				BlockPos pos = entity.blockPosition();
				long packed = pos.asLong();
				Long previous = LAST_BLOCK.put(entity.getUUID(), packed);
				// First sighting or same block as before: no footprint.
				if (previous == null || previous == packed) continue;
				compress(level, pos);
			}
		}
	}

	private static void compress(ServerLevel level, BlockPos pos) {
		BlockState state = level.getBlockState(pos);
		if (!state.is(Blocks.SNOW)) return;
		int layers = state.getValue(SnowLayerBlock.LAYERS);
		if (layers > 1) {
			level.setBlock(pos, state.setValue(SnowLayerBlock.LAYERS, layers - 1), 3);
		}
	}

	/** During precipitation, existing snow layers near players slowly grow deeper (only where it actually snows). */
	private static void accumulate(ServerLevel level) {
		for (ServerPlayer player : level.players()) {
			BlockPos origin = player.blockPosition();
			for (int i = 0; i < ATTEMPTS_PER_TICK; i++) {
				int x = origin.getX() + level.getRandom().nextInt(RADIUS * 2 + 1) - RADIUS;
				int z = origin.getZ() + level.getRandom().nextInt(RADIUS * 2 + 1) - RADIUS;
				if (!level.hasChunkAt(new BlockPos(x, origin.getY(), z))) continue;

				BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, new BlockPos(x, 0, z));
				// Thin snow layers don't block motion, so the heightmap may point at the layer or just above it.
				if (!tryGrow(level, top)) tryGrow(level, top.below());
			}
		}
	}

	private static boolean tryGrow(ServerLevel level, BlockPos pos) {
		BlockState state = level.getBlockState(pos);
		if (!state.is(Blocks.SNOW)) return false;
		int layers = state.getValue(SnowLayerBlock.LAYERS);
		if (layers >= MAX_LAYERS) return true; // it's snow, just full; don't also try the block below
		if (!level.getBiome(pos).value().shouldSnow(level, pos)) return true;
		level.setBlock(pos, state.setValue(SnowLayerBlock.LAYERS, layers + 1), 3);
		return true;
	}
}
