package com.realsnow;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Server-side logic. Works on dedicated servers and in singleplayer.
 * Players without the mod still see snow pile up and get footprints (vanilla models);
 * players WITH the mod also get the soft, rounded snow look.
 */
public class RealSnow implements ModInitializer {
	public static final String MOD_ID = "realsnow";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// END_SERVER_TICK was not part of the 26.1 renames (only *_WORLD_* client events were), so this is safe.
		ServerTickEvents.END_SERVER_TICK.register(SnowPhysics::onServerTick);
		LOGGER.info("Real Snow loaded");
	}
}
