# Real Snow (Fabric, Minecraft 26.1.2)

Server + client in one jar.
- Server (works for everyone): snow layers pile up to 5 deep during snowfall near players; players/mobs compress layers into footprints/trails.
- Client (only players with the mod): rounded "pillow" snow models, soft bluish-white texture, denser snowfall particles.

Requirements: Java 25, Fabric Loader 0.19.2+, Fabric API 0.146.1+26.1.2

Build: `./gradlew build` -> build/libs/realsnow-1.0.0.jar
Dedicated server: put the jar + Fabric API in /mods. Clients may install it too for the visuals.
Tweak buildup in SnowPhysics.java (MAX_LAYERS, ATTEMPTS_PER_TICK, RADIUS).
